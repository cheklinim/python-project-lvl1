### Hexlet tests and linter status:
[![Actions Status](https://github.com/cheklinim/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/cheklinim/python-project-lvl1/actions)

### CodeClimate badges:
[![Maintainability](https://api.codeclimate.com/v1/badges/f89dacd6c5ef102759f1/maintainability)](https://codeclimate.com/github/cheklinim/python-project-lvl1/maintainability)

### asciinema casts:
[![asciicast](https://asciinema.org/a/OG5NMHfbOXkM2S2Slmm3hKdqz.svg)](https://asciinema.org/a/OG5NMHfbOXkM2S2Slmm3hKdqz)
[![asciicast](https://asciinema.org/a/Zy7J6xbFV5P0hlvTnhi3EunsW.svg)](https://asciinema.org/a/Zy7J6xbFV5P0hlvTnhi3EunsW)
[![asciicast](https://asciinema.org/a/74AAOF9zFw3lw9UMIg7gWe0M9.svg)](https://asciinema.org/a/74AAOF9zFw3lw9UMIg7gWe0M9)
[![asciicast](https://asciinema.org/a/8Od0VFd3cjrwD6i8CqM9sULrb.svg)](https://asciinema.org/a/8Od0VFd3cjrwD6i8CqM9sULrb)
