"""Module for games logic"""
