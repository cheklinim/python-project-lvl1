"""The game about simple calculations"""

from brain_games.lib.games.game_calc import game_calc


def main():
    """Main function of module"""
    game_calc()


if __name__ == '__main__':
    main()
