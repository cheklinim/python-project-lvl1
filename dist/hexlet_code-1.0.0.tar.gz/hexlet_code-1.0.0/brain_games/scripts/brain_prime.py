"""The game about prime numbers"""

from brain_games.lib.games.game_prime import game_prime


def main():
    """Main function of module"""
    game_prime()


if __name__ == '__main__':
    main()
