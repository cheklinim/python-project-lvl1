### Hexlet tests and linter status:
[![Actions Status](https://github.com/cheklinim/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/cheklinim/python-project-lvl1/actions)