"""Calculations library module."""


def is_even(x):
    return not (x % 2)


def main():
    print('This is library module. It should be imported')


if __name__ == '__main__':
    main()
