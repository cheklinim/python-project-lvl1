"""The game about simple calculations"""

from brain_games.lib.games.game_gcd import game_gcd


def main():
    """Main function of module"""
    game_gcd()


if __name__ == '__main__':
    main()
