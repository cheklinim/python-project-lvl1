"""The game about progression"""

from brain_games.lib.games.game_progression import game_progression


def main():
    """Main function of module"""
    game_progression()


if __name__ == '__main__':
    main()
