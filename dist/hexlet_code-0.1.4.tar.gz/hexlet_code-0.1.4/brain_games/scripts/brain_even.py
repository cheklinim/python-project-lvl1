"""The game about odd-even numbers."""

from brain_games.lib.games import game_even

def main():
    game_even()


if __name__ == '__main__':
    main()
