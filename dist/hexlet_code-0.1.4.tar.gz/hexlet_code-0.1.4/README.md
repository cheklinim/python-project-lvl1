### Hexlet tests and linter status:
[![Actions Status](https://github.com/cheklinim/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/cheklinim/python-project-lvl1/actions)

### CodeClimate badges:
[![Maintainability](https://api.codeclimate.com/v1/badges/f89dacd6c5ef102759f1/maintainability)](https://codeclimate.com/github/cheklinim/python-project-lvl1/maintainability)
