"""Module for scripts."""
